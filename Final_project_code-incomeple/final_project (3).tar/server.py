from flask import Flask
from EmotionDetection import emotion_detection

app =  Flask('Emotion Detection App')

@app.route("/emotionDetector")
def home():
    input_stmt = "I love my life"
    response =  emotion_detection.emotion_detector(input_stmt)
    output = """For the given statement, the system response is 'anger': {}, 'disgust': {}, 'fear': {}, 'joy': {} and 'sadness': {}. 
    The dominant emotion is {}.""".format(response['anger'], response['disgust'],response['fear'],response['joy'],response['sadness'],response['dominant_emotion'],)
    
    return output

if __name__ == '__main__':
    app.run(port=5000,debug=True)

